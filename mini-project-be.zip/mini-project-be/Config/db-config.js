module.exports = {
  USER: "root",
  PASSWORD: "admin",
  HOST: "127.0.0.1",
  PORT: "3306",
  DATABASE: "training_project_db",
  DIALECT: "mysql",
};
