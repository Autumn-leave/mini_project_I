import React from 'react';
import axios from 'axios';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as yup from 'yup';

const validationSchema = yup.object().shape({
    username: yup.string()
    .required('Username is required'),
    email: yup.string()
    .email('Invalid email')
    .test('com-domain', 'Email must have .com domain', (value) => {
        if (!value) return true; // Skip validation if value is empty
        return value.endsWith('.com');
      })
      .required('Email is required'),
    password: yup.string()
    .min(6, 'Password must be at least 6 characters')
    .required('Password is required'),
    confirmPassword: yup.string()
    .oneOf([yup.ref('password'), null], 'Passwords must match')
    .required('Confirm Password is required'),
  });

 function Signup(){
    const handleSubmit = async (values, {resetForm}) => {
    {console.log(values)}
    const response1 = await axios.post('http://localhost:5000/users/',{
        
        username : values.username, 
        password : values.password,
        email : values.email, 
    }).then((res)=>{
        console.log(res);
        resetForm();
    }).catch((d)=>{
        alert("Email ID or Username already exists!");
    })
    };
  
    return (
      <div className='container'>
        <Formik
        initialValues={{
          username: '',
          email: '',
          password: '',
          confirmPassword: '',
        }}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
         <Form>
        <div className="mb-3">
          <label htmlFor="username">Username:</label>
          <Field type="text" className="form-control" id="username" name="username" />
          <ErrorMessage name="username" component="div" className="text-danger" />
        </div>
        <div className="mb-3">
          <label htmlFor="email">Email:</label>
          <Field type="email" className="form-control" id="email" name="email" />
          <ErrorMessage name="email" component="div" className="text-danger" />
        </div>
        <div className="mb-3">
          <label htmlFor="password">Password:</label>
          <Field type="password" className="form-control" id="password" name="password" />
          <ErrorMessage name="password" component="div" className="text-danger" />
        </div>
        <div className="mb-3">
          <label htmlFor="confirmPassword">Confirm Password:</label>
          <Field type="password" className="form-control" id="confirmPassword" name="confirmPassword" />
          <ErrorMessage name="confirmPassword" component="div" className="text-danger" />
        </div>
        <div className='buton'>
        <button type="submit" className="btn btn-primary">Sign Up</button>
        </div>
      </Form>
      </Formik>
      </div>
    );
  }
  
  export default Signup;


// const handleSignup = async () => {
//     // Send a POST request to backend API for signup
//     const response = await fetch('/', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//       },
//       body: JSON.stringify({ username, email, password }),
//     });
//     const data = await response.json();
//     console.log(data); // Handle response from backend
//   };

// <Formik
//         initialValues={{
//           username: '',
//           email: '',
//           password: '',
//           confirmPassword: '',
//         }}
//         validationSchema={validationSchema}
//         onSubmit={handleSubmit}
//       >
//          <Form>
//         <div className="mb-3">
//           <label htmlFor="username">Username:</label>
//           <Field type="text" className="form-control" id="username" name="username" />
//           <ErrorMessage name="username" component="div" className="text-danger" />
//         </div>
//         <div className="mb-3">
//           <label htmlFor="email">Email:</label>
//           <Field type="email" className="form-control" id="email" name="email" />
//           <ErrorMessage name="email" component="div" className="text-danger" />
//         </div>
//         <div className="mb-3">
//           <label htmlFor="password">Password:</label>
//           <Field type="password" className="form-control" id="password" name="password" />
//           <ErrorMessage name="password" component="div" className="text-danger" />
//         </div>
//         <div className="mb-3">
//           <label htmlFor="confirmPassword">Confirm Password:</label>
//           <Field type="password" className="form-control" id="confirmPassword" name="confirmPassword" />
//           <ErrorMessage name="confirmPassword" component="div" className="text-danger" />
//         </div>
//         <button type="submit" className="btn btn-primary">Sign Up</button>
//       </Form>
//       </Formik>