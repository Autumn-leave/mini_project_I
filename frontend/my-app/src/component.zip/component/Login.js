
import React from "react";
import * as yup from 'yup';
import axios from 'axios';
import { Formik, Form, Field, ErrorMessage } from 'formik';

const validationSchema = yup.object().shape({
    username: yup.string()
        .required("Username is required"),
    password: yup.string()
        .required("Password is required"),
});

function Login() {
    const handleSubmit = async (values, { resetForm }) => {
        const response1 = await axios.post('http://localhost:5000/users/login', {
            username: values.username,
            password: values.password,
        }).then((res) => {
            console.log(res);
            resetForm();
        }).catch((d) => {
            alert("Email ID or Password is wrong!");
        })
    };
    return (
        <div className="container">
            <Formik
                initialValues={{
                    username: '',
                    password: '',
                }}
                validationSchema={validationSchema}
                onSubmit={handleSubmit}
            >
                <Form>
                    <div className="mb-3">
                        <label htmlFor="username">Username:</label>
                        <Field type="text" className="form-control in-color" id="username" name="username" required/>
                        <ErrorMessage name="username" component="div" className="text-danger" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="password">Password:</label>
                        <Field type="password" className="form-control in-color" id="password" name="password" />
                        <ErrorMessage name="password" component="div" className="text-danger" />
                    </div>
                    <div className='buton'>
                        <button type="submit" className="btn btn-primary">Login</button>
                    </div>
                </Form>
            </Formik>
        </div>
    )
}

export default Login;